<?php
include_once 'connect.php';

class Menu {
    protected $text;
    protected $sessionId;
    protected $pdo;

    function __construct($text, $sessionId) {
        $this->text = $text;
        $this->sessionId = $sessionId;
        $this->pdo = getCon();
    }
    
    public function checkUserCredentials($phoneNumber, $password) {
        $sql = "SELECT * FROM users WHERE phone = ? AND password = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$phoneNumber, $password]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        return $user;
    } 
    
    private function createHistoricTable() {
        $sql = "CREATE TABLE IF NOT EXISTS historic (
                    history_id INT AUTO_INCREMENT PRIMARY KEY,
                    order_id INT NOT NULL,
                    date DATETIME NOT NULL,
                    status VARCHAR(50) NOT NULL,
                    FOREIGN KEY (order_id) REFERENCES orders(order_id)
                )";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
    }
    
    public function retrieveAppendingOrders($user_id) {
        try {
            $sql = "SELECT orders.order_id, menu_items.name, menu_items.price 
                    FROM orders 
                    INNER JOIN menu_items ON orders.item_id = menu_items.item_id 
                    WHERE user_id='$user_id' and  orders.status = 'Pending'";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $appendingOrders = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $appendingOrders;
        } catch (PDOException $e) {
            return false;
        }
    }

    public function insertOrder($userId, $itemId, $status = 'Pending') {
        $sql = "INSERT INTO orders (user_id, item_id, status) VALUES (?, ?, ?)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$userId, $itemId, $status]);
        return $this->pdo->lastInsertId(); 
    }

    public function retrieveApprovedOrders() {
        try {
            $sql = "SELECT orders.order_id, menu_items.name, menu_items.price 
                    FROM orders 
                    INNER JOIN menu_items ON orders.item_id = menu_items.item_id 
                    WHERE orders.status = 'approved'";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $approvedOrders = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $approvedOrders;
        } catch (PDOException $e) {
            return false;
        }
    }

    public function checkPendingOrders($userId, $itemId) {
        $sql = "SELECT COUNT(*) AS count FROM orders WHERE user_id = ? AND item_id = ? AND status = 'Pending'";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$userId, $itemId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] > 0;
    }

    public function mainMenuUnregistered() {
        $response = "CON Welcome to Enjoy Restraint \n";
        $response .= "1. Register\n";
        echo $response;
    }

    public function checkPhoneNumberExists($phoneNumber) {
        $sql = "SELECT *, COUNT(*) AS count FROM users WHERE phone = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$phoneNumber]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function menuRegister($textArray, $phoneNumber) {
        // Registration logic
        $level = count($textArray);
        if($level == 1) {
            echo "CON Enter your Email\n";
        } else if($level == 2) {
            echo "CON Enter RegNumber\n";
        } else if($level == 3) {
            echo "CON Set your PIN\n";
        } else if($level == 4) {
            echo "CON Re-enter PIN\n";
        } else {
            $email = $textArray[1];
            $RegNumber = $textArray[2];
            $pin = $textArray[3];
            $confirm_pin = $textArray[4];
            $check = $this->checkPhoneNumberExists($phoneNumber);

            if($check){
                if($pin != $confirm_pin) {
                    echo "END PINs do not match, Retry";
                } else {
                    $sel = $this->pdo->prepare("SELECT * FROM users where phone='$phoneNumber'");
                    $sel->execute();
                    $select = $sel->fetch(PDO::FETCH_ASSOC);
                    if($select) {
                        echo "END the phone number is already exist";
                    } else {
                        $sql = "INSERT INTO users (email, RegNumber, password, phone) VALUES (?, ?, ?, ?)";
                        $stmt = $this->pdo->prepare($sql);
                        $stmt->execute([$email, $RegNumber, $pin, $phoneNumber]);
                        if($stmt) {
                            echo "END $textArray[1], You have successfully registered";
                        } else {
                            echo "END $textArray[1], You have failed registered";
                        }
                    }
                }
            }else{
                echo "END Invalid credential.";
            }
        }
    }

    public function mainMenuRegistered() {
        $response = "Welcome tO Enjoy Restraint Ordering System\n";
        $response .= "1. Ordering\n";
        $response .= "2. Payment\n";
        $response .= "3. View ordering\n";
        $response .= "4. check balance\n";
        $response .= "99. Back to Menu\n";
        $response .= "00. Check Cancel\n";
        echo $response;
    }

    public function menuOrdering($textArray, $phoneNumber) {
        $level = count($textArray);
        if ($level == 1) {
            $sql = "SELECT * FROM menu_items";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            if ($stmt->rowCount() > 0) {
                $menuItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $response = "CON Please select an item from the menu:\n";
                foreach ($menuItems as $item) {
                    $response .= $item['item_id'] . ". " . $item['name'] . " - Price: $" . $item['price'] . "\n";
                }
                $response .= "99. Back to Menu\n";
                echo $response;
            } else {
                echo "END No items available in the menu. Please try again later.";
            }
        } elseif ($level == 2) {
            echo "END Enter PIN.";
        } elseif ($level == 3) {
            if ($textArray[1] == '99') {
                $this->mainMenuRegistered();
                return;
            } elseif ($textArray[1] == '00') {
                echo "END Order canceled.";
                return;
            } else {
                $itemNumber = (int) $textArray[1];
                $password = (int) $textArray[2];
                $check = $this->checkUserCredentials($phoneNumber, $password);
                if($check){
                    $sql = "SELECT * FROM menu_items WHERE item_id = ?";
                    $stmt = $this->pdo->prepare($sql);
                    $stmt->execute([$itemNumber]);
                    if ($stmt->rowCount() > 0) {
                        $item = $stmt->fetch(PDO::FETCH_ASSOC);
                        $row = $this->checkPhoneNumberExists($phoneNumber);
                        if (!$row) {
                            // New phone number, prompt for registration
                            $response = "CON You are not registered. Please proceed with registration.\n";
                            $response .= "Enter your Email\n";
                            echo $response;
                            return;
                        }
                        // Existing user, continue with ordering process
                        $userId = $row['user_id'];
                        $itemId = $itemNumber;
                        $ord = $this->checkPendingOrders($userId, $itemId);
                        if ($ord) {
                            $response = "END You have failed to order: " . $item['name'] . " - Price: $" . $item['price'] . " there is still a pending order\n";
                        } else {
                            $orderId = $this->insertOrder($userId, $itemId);
                            if ($orderId) {
                                // Provide options for payment
                                $response = "CON You have successfully ordered: " . $item['name'] . " - Price: $" . $item['price'] . "\n";
                                $response .= "Do you want to proceed to payment?\n";
                                $response .= "1. Yes\n";
                                $response .= "2. No, back to menu\n";
                                // Save the order ID in session for later payment
                                $_SESSION['pending_order_id'] = $orderId;
                            } else {
                                $response = "END You have failed to order: " . $item['name'] . " - Price: $" . $item['price'] . "\n";
                            }
                        }
                        echo $response;
                    } else {
                        echo "END Invalid item number. Please select a valid item number from the list.";
                    }
                } else {
                    echo "END Invalid credential.";
                }
            }
        } elseif ($level == 4) {
            if ($textArray[3] == '1') {
                $row = $this->checkPhoneNumberExists($phoneNumber);
                if (!$row) {
                    // New phone number, prompt for registration
                    $response = "CON You are not registered. Please proceed with registration.\n";
                    $response .= "Enter your Email\n";
                    echo $response;
                    return;
                }
                // Existing user, continue with ordering process
                $userId = $row['user_id'];
                $appendingOrders = $this->retrieveAppendingOrders( $userId);
                if ($appendingOrders) {
                    // Display appending orders
                    $response = "CON Appending Orders:\n";
                    foreach ($appendingOrders as $order) {
                        $response .= "Order ID: " . $order['order_id'] . ", Item: " . $order['name'] . ", Price: $" . $order['price'] . "\n";
                    }
                    $response .= "Enter the order ID to approve or 99 to cancel.\n";
                    echo $response;
                } else {
                    echo "END No appending orders found.";
                }
            } elseif ($textArray[3] == '2') {
                echo "END Success to cancel.";
            } else {
                echo "END Invalid choice.";
            }
        }elseif ($level == 5) {
            if ($textArray[3] == '1') {
                $orderId = (int)$textArray[4];
                $password = $textArray[2];
                $user = $this->checkUserCredentials($phoneNumber, $password);
                if ($user) {
                    // User credentials are valid
                    $userId = $user['user_id'];
                    // Check if the order exists and belongs to the user
                    $sql = "SELECT * FROM orders,menu_items WHERE  order_id = ? AND user_id = ?";
                    $stmt = $this->pdo->prepare($sql);
                    $stmt->execute([$orderId, $userId]);
                    $order = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($order) {
                        // Retrieve user's balance
                        $sql = "SELECT amount FROM balance WHERE user_id = ?";
                        $stmt = $this->pdo->prepare($sql);
                        $stmt->execute([$userId]);
                        $balance = $stmt->fetchColumn();
                        if ($balance !== false) {
                            // Check if the balance is sufficient
                            $orderPrice = $order['price'];
                            if ($balance >= $orderPrice) {
                                // Update order status to approved
                                $sql = "UPDATE orders SET status = 'approved' WHERE order_id = ?";
                                $stmt = $this->pdo->prepare($sql);
                                $stmt->execute([$orderId]);
                                
                                // Deduct order price from user's balance
                                $newBalance = $balance - $orderPrice;
                                $sql = "UPDATE balance SET amount = ? WHERE user_id = ?";
                                $stmt = $this->pdo->prepare($sql);
                                $stmt->execute([$newBalance, $userId]);
                                
                                // Check if the historic table exists, if not create it
                                $this->createHistoricTable();
                                
                                // Insert into historic table
                                $sql = "INSERT INTO historic (order_id, date, status) VALUES (?, NOW(), 'approved')";
                                $stmt = $this->pdo->prepare($sql);
                                $stmt->execute([$orderId]);
                                
                                echo "END Order approved. Remaining balance: $" . $newBalance;
                            } else {
                                echo "END Insufficient balance.";
                            }
                        } else {
                            echo "END Failed to retrieve balance.";
                        }
                    } else {
                        echo "END Order not found or does not belong to you.";
                    }
                } else {
                    echo "END Invalid phone number or PIN.";
                }

                
            } else {
                echo "END Invalid choice.";
            }
        } else {
            echo "END Invalid input for menu ordering\n";
        }
    }
    
    public function viewOrders($textArray, $phoneNumber) {
        $level = count($textArray);
        if ($level == 1) {
            $response = "CON Choose operation\n";
            $response .= "1. View Appending Orders\n";
            $response .= "2. View Approved Orders\n";
            $response .= "99. Back to Menu\n";
            $response .= "00. Cancel\n";
            echo $response;
        } else if ($level == 2) {
            if ($textArray[1] == '99') {
                $this->mainMenuRegistered();
                return;
            } elseif ($textArray[1] == '00') {
                echo "END Operation canceled.";
                return;
            } else {
                echo "CON Enter PIN\n";
            }
        } elseif ($level == 3) {
            $password = $textArray[2];
            $user = $this->checkUserCredentials($phoneNumber, $password);
            if ($user) {
                $userId = $user['user_id'];
                if ($textArray[1] == '1') {
                    // View appending orders for the current user
                    $appendingOrders = $this->retrieveAppendingOrders($userId);
                    if ($appendingOrders) {
                        $response = "CON Appending Orders:\n";
                        foreach ($appendingOrders as $order) {
                            $response .= "Order ID: " . $order['order_id'] . ", Item: " . $order['name'] . ", Price: $" . $order['price'] . "\n";
                        }
                        $response .= "99. Back to Menu\n";
                        echo $response;
                    } else {
                        echo "END There are no appending orders.\n";
                    }
                } elseif ($textArray[1] == '2') {
                    // View approved orders for the current user
                    $approvedOrders = $this->retrieveApprovedOrders($userId); 
                    if ($approvedOrders) {
                        $response = "CON Approved Orders:\n";
                        foreach ($approvedOrders as $order) {
                            $response .= "Order ID: " . $order['order_id'] . ", Item: " . $order['name'] . ", Price: $" . $order['price'] . "\n";
                        }
                        $response .= "99. Back to Menu\n";
                        echo $response;
                    } else {
                        echo "END There are no approved orders.\n";
                    }
                } else {
                    echo "END Invalid input.\n";
                }
            } else {
                echo "END Invalid credential.\n";
            }
        } elseif ($level == 4) {
            if ($textArray[3] == '99') {
                $this->mainMenuRegistered();
                return;
            } elseif ($textArray[3] == '00') {
                echo "END Operation canceled.";
                return;
            } else {
                echo "END Invalid input.";
            }
        } else {
            echo "END Invalid input for menu ordering.\n";
        }
    }
    
    public function CheckBalance($textArray, $phoneNumber) {
        $level = count($textArray);
        if ($level == 1) {
            echo "CON Enter your PIN\n";
        } elseif ($level == 2) {
            $password = $textArray[1];
            $user = $this->checkUserCredentials($phoneNumber, $password);
            if ($user) {
                // User credentials are valid, retrieve balance
                $userId = $user['user_id'];
                $sql = "SELECT amount FROM balance WHERE user_id = ?";
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute([$userId]);
                $balance = $stmt->fetchColumn();
                if ($balance !== false) {
                    echo "END Your current balance is: $" . $balance;
                } else {
                    echo "END Failed to retrieve balance.";
                }
            } else {
                echo "END Invalid phone number or PIN.";
            }
        } else {
            echo "END Invalid input for checking balance.";
        }
    }

    public function menuPayment($textArray,$phoneNumber) {
        $level = count($textArray);
        if ($level == 1) {
            echo "CON Enter your PIN\n";
        } elseif ($level == 2) {
            $password = $textArray[1];
            $user = $this->checkUserCredentials($phoneNumber, $password);
            if ($user) {
                // User credentials are valid, retrieve appending orders
                $userId = $user['user_id'];
                $appendingOrders = $this->retrieveAppendingOrders($userId);
                if ($appendingOrders) {
                    // Display appending orders
                    $response = "CON Appending Orders:\n";
                    foreach ($appendingOrders as $order) {
                        $response .= "Order ID: " . $order['order_id'] . ", Item: " . $order['name'] . ", Price: $" . $order['price'] . "\n";
                    }
                    $response .= "Enter the order ID to approve or 99 to cancel.\n";
                    echo $response;
                } else {
                    echo "END No appending orders found.";
                }
            } else {
                echo "END Invalid phone number or PIN.";
            }
        } elseif ($level == 3) {
            $orderId = (int)$textArray[2];
            $password = $textArray[1];
            $user = $this->checkUserCredentials($phoneNumber, $password);
            if ($user) {
                // User credentials are valid
                $userId = $user['user_id'];
                // Check if the order exists and belongs to the user
                $sql = "SELECT * FROM orders,menu_items WHERE  order_id = ? AND user_id = ?";
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute([$orderId, $userId]);
                $order = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($order) {
                    // Retrieve user's balance
                    $sql = "SELECT amount FROM balance WHERE user_id = ?";
                    $stmt = $this->pdo->prepare($sql);
                    $stmt->execute([$userId]);
                    $balance = $stmt->fetchColumn();
                    if ($balance !== false) {
                        // Check if the balance is sufficient
                        $orderPrice = $order['price'];
                        if ($balance >= $orderPrice) {
                            // Update order status to approved
                            $sql = "UPDATE orders SET status = 'approved' WHERE order_id = ?";
                            $stmt = $this->pdo->prepare($sql);
                            $stmt->execute([$orderId]);
                            
                            // Deduct order price from user's balance
                            $newBalance = $balance - $orderPrice;
                            $sql = "UPDATE balance SET amount = ? WHERE user_id = ?";
                            $stmt = $this->pdo->prepare($sql);
                            $stmt->execute([$newBalance, $userId]);
                            
                            // Check if the historic table exists, if not create it
                            $this->createHistoricTable();
                            
                            // Insert into historic table
                            $sql = "INSERT INTO historic (order_id, date, status) VALUES (?, NOW(), 'approved')";
                            $stmt = $this->pdo->prepare($sql);
                            $stmt->execute([$orderId]);
                            
                            echo "END Order approved. Remaining balance: $" . $newBalance;
                        } else {
                            echo "END Insufficient balance.";
                        }
                    } else {
                        echo "END Failed to retrieve balance.";
                    }
                } else {
                    echo "END Order not found or does not belong to you.";
                }
            } else {
                echo "END Invalid phone number or PIN.";
            }
        } else {
            echo "END Invalid input for payment";
        }
    }
}
?>
