<?php
include_once 'menu.php';
include_once("connect.php");
include_once ('util.php');

function isNotRegistered($phoneNumber, $pdo) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE phone= ?");
    $stmt->execute([$phoneNumber]); // Bind the parameter
    $count = $stmt->fetchColumn(); // Fetch the result into $count
    return $count == 0; 
}

// Check if 'from' and 'text' keys exist in the $_POST array
if(isset($_POST['from']) && isset($_POST['text'])) {
    $phoneNumber = $_POST['from'];
    $text = $_POST['text']; 

    $textArray = explode(" ", $text);

    if(isset($textArray[0]) && isset($textArray[1]) && isset($textArray[2])) {
        $RegNumber = $textArray[0];
        $email= $textArray[1];
        $password = $textArray[2];
       


        if(isNotRegistered($phoneNumber, $pdo)) {
            $stmt = $pdo->prepare("INSERT INTO users (RegNumber,email , phone,password,status) VALUES (?, ?, ?,? ,?)");
            if ($stmt->execute([$RegNumber, $email, $phoneNumber, $password, $status='Active'])) {
                $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
                $stmt->execute([$email]);
                $value = $stmt->fetch(PDO::FETCH_ASSOC);
                echo "END Thank you {$value['email']}, you have been successfully registered!";
            } else {
                echo "END Registration failed. Please try again later.";
            }
        } else {
            echo "END User is already registered.";
        }
    } else {
        // If any of the parameters is missing in the SMS, prompt the user to provide all parameters
        echo "END Your SMS must contain all required parameters: RegNumber, email, phone, password, status.";
    }
} else {
    // If 'from' or 'text' keys are missing in the $_POST array, prompt the user to provide them
    echo "END Please provide both 'from' and 'text' parameters.";
}
?>
