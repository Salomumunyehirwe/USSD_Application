<?php
include_once 'connect.php';
include_once 'menu.php';

$sessionId = $_POST['sessionId'];
$phoneNumber = $_POST['phoneNumber'];
$serviceCode = $_POST['serviceCode'];
$text = $_POST['text'];
$menu = new Menu($text, $sessionId);
$result=$menu->checkPhoneNumberExists($phoneNumber);
if($result['user_id']){
    $status=true;
}else{
    $status=false; 
}
$isRegistered = $status;

if ($text == "" && !$isRegistered) {
    // User is not registered and didn't enter any input
    $menu->mainMenuUnregistered();
} elseif ($text == "" && $isRegistered) {
    // User is registered and didn't enter any input
    $menu->mainMenuRegistered();
} elseif (!$isRegistered) {
    // User is not registered and entered input
    $textArray = explode("*", $text);
    switch ($textArray[0]) {
        case 1:
            $menu->menuRegister($textArray, $phoneNumber);
            break;
        default:
            echo "END Invalid option, please retry";
    }
} else {
    // User is registered and entered input
    $textArray = explode("*", $text);
    switch ($textArray[0]) {
        case 1:
            $menu->menuOrdering($textArray, $phoneNumber);
            break;
        case 2:
            $menu->menuPayment($textArray, $phoneNumber);
            break;
        case 3:
            // Handle view ordering
            $menu->viewOrders($textArray, $phoneNumber);
            break;
        case 4:
            // Handle check balance
            $menu->CheckBalance($textArray, $phoneNumber);
            break;
        case 00:
            // Handle menu option 00
            echo "END Exit USSD service"; 
            break;
        case 99:
            // Handle menu option 99
            echo "CON Main menu\n"; // Redirect to main menu
            $menu->mainMenuRegistered();
            break;
        default:
            echo "END Invalid choice";
    }
}
?>
